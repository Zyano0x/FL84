#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x40 - 0x40)
// BlueprintGeneratedClass BP_Soroll03_QuickSummon_Forward.BP_Soroll03_QuickSummon_Forward_C
class UBP_Soroll03_QuickSummon_Forward_C : public UBP_QuickSummon_Forward_C
{
public:

	static class UClass* StaticClass();
	static class UBP_Soroll03_QuickSummon_Forward_C* GetDefaultObj();

};

}


