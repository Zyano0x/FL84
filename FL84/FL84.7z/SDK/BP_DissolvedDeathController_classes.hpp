#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x40 - 0x40)
// BlueprintGeneratedClass BP_DissolvedDeathController.BP_DissolvedDeathController_C
class UBP_DissolvedDeathController_C : public UTimedEffectController
{
public:

	static class UClass* StaticClass();
	static class UBP_DissolvedDeathController_C* GetDefaultObj();

};

}


