#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x848 - 0x848)
// BlueprintGeneratedClass GE_EMP.GE_EMP_C
class UGE_EMP_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UGE_EMP_C* GetDefaultObj();

};

}


