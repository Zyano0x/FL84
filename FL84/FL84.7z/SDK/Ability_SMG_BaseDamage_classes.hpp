#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x318 - 0x308)
// BlueprintGeneratedClass Ability_SMG_BaseDamage.Ability_SMG_BaseDamage_C
class AAbility_SMG_BaseDamage_C : public ASolarAbility
{
public:
	uint8                                        Pad_1C3F[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x310(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class AAbility_SMG_BaseDamage_C* GetDefaultObj();

};

}


