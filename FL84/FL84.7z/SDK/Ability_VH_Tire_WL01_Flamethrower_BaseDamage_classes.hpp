#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x310 - 0x308)
// BlueprintGeneratedClass Ability_VH_Tire_WL01_Flamethrower_BaseDamage.Ability_VH_Tire_WL01_Flamethrower_BaseDamage_C
class AAbility_VH_Tire_WL01_Flamethrower_BaseDamage_C : public ASolarAbility
{
public:
	uint8                                        Pad_BB1[0x8];                                      // Fixing Size Of Struct [ Dumper-7 ]

	static class UClass* StaticClass();
	static class AAbility_VH_Tire_WL01_Flamethrower_BaseDamage_C* GetDefaultObj();

};

}


