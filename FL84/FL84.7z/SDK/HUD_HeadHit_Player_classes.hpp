#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x350 - 0x348)
// WidgetBlueprintGeneratedClass HUD_HeadHit_Player.HUD_HeadHit_Player_C
class UHUD_HeadHit_Player_C : public USolarUserWidget
{
public:
	class UWidgetAnimation*                      Anim_HeadHit_Player;                               // 0x348(0x8)(BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UHUD_HeadHit_Player_C* GetDefaultObj();

};

}


