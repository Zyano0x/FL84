#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x1F8 (0x1F8 - 0x0)
// ScriptStruct Str_2PointLightData.Str_2PointLightData
struct FStr_2PointLightData
{
public:
	struct FStr_2PointLightDetail                Zero_Defualt2D_31_474EC33249F07E2CB3D3119047FA8ED0; // 0x0(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                One_Character_32_B83771234E434E6FEC99149BA5C68BA5; // 0x48(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                Two_Capsule_33_DF855FC7426381AB3F4A9CA7DF08081F;   // 0x90(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                Three_Weapone_34_B661C2CE4AEB141B7D6A4FBE7DE88026; // 0xD8(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                Four_Vehicale_35_195E5C9A4D3D5E516F71829CD626CF09; // 0x120(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                Five_BagTrail_38_1FB089FE4CF113F5A4B7BBB4EDAE4DEA; // 0x168(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
	struct FStr_2PointLightDetail                Six_Gold_41_168D9AEA40E1E813CE632BB5A8A4620A;      // 0x1B0(0x48)(Edit, BlueprintVisible, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

}


