#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x320 - 0x320)
// BlueprintGeneratedClass BP_SolarAbility_WL07_EMP.BP_SolarAbility_WL07_EMP_C
class ABP_SolarAbility_WL07_EMP_C : public ASolarWeaponAbilityTemp
{
public:

	static class UClass* StaticClass();
	static class ABP_SolarAbility_WL07_EMP_C* GetDefaultObj();

};

}


