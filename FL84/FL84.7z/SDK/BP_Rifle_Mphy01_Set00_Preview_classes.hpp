#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x688 - 0x688)
// BlueprintGeneratedClass BP_Rifle_Mphy01_Set00_Preview.BP_Rifle_Mphy01_Set00_Preview_C
class ABP_Rifle_Mphy01_Set00_Preview_C : public ABP_Weaponry_Base_Preview_C
{
public:

	static class UClass* StaticClass();
	static class ABP_Rifle_Mphy01_Set00_Preview_C* GetDefaultObj();

};

}


