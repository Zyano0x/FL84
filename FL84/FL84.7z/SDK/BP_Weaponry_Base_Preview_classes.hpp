#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x688 - 0x660)
// BlueprintGeneratedClass BP_Weaponry_Base_Preview.BP_Weaponry_Base_Preview_C
class ABP_Weaponry_Base_Preview_C : public AWeaponryWeapon
{
public:
	class UWeaponryPartClip*                     WeaponryPartClip;                                  // 0x660(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)
	class UWeaponryPartScope*                    WeaponryPartScope;                                 // 0x668(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)
	class UWeaponryPartMuzzle*                   WeaponryPartMuzzle;                                // 0x670(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)
	class UWeaponryPartGunStock*                 WeaponryPartGunStock;                              // 0x678(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)
	class UWeaponryPartGrip*                     WeaponryPartGrip;                                  // 0x680(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_Weaponry_Base_Preview_C* GetDefaultObj();

};

}


