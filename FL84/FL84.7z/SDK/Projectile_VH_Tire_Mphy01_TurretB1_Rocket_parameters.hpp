#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x88 (0x88 - 0x0)
// Function Projectile_VH_Tire_Mphy01_TurretB1_Rocket.Projectile_VH_Tire_Mphy01_TurretB1_Rocket_C.BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
struct AProjectile_VH_Tire_Mphy01_TurretB1_Rocket_C_BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature_Params
{
public:
	struct FHitResult                            ImpactResult;                                      // 0x0(0x88)(ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
};

// 0x8C (0x8C - 0x0)
// Function Projectile_VH_Tire_Mphy01_TurretB1_Rocket.Projectile_VH_Tire_Mphy01_TurretB1_Rocket_C.ExecuteUbergraph_Projectile_VH_Tire_Mphy01_TurretB1_Rocket
struct AProjectile_VH_Tire_Mphy01_TurretB1_Rocket_C_ExecuteUbergraph_Projectile_VH_Tire_Mphy01_TurretB1_Rocket_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FHitResult                            K2Node_ComponentBoundEvent_ImpactResult;           // 0x4(0x88)(ConstParm, IsPlainOldData, NoDestructor, ContainsInstancedReference)
};

}
}


