#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x170 - 0x170)
// BlueprintGeneratedClass BP_SolarGameSettingsRange_PC.BP_SolarGameSettingsRange_PC_C
class UBP_SolarGameSettingsRange_PC_C : public USolarGameSettingsRange
{
public:

	static class UClass* StaticClass();
	static class UBP_SolarGameSettingsRange_PC_C* GetDefaultObj();

};

}


