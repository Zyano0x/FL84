#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x688 - 0x688)
// BlueprintGeneratedClass BP_SMG_Psm03_Set00_Preview.BP_SMG_Psm03_Set00_Preview_C
class ABP_SMG_Psm03_Set00_Preview_C : public ABP_Weaponry_Base_Preview_C
{
public:

	static class UClass* StaticClass();
	static class ABP_SMG_Psm03_Set00_Preview_C* GetDefaultObj();

};

}


