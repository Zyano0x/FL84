#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x848 - 0x848)
// BlueprintGeneratedClass BPGE_UsingContinuousSkill.BPGE_UsingContinuousSkill_C
class UBPGE_UsingContinuousSkill_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UBPGE_UsingContinuousSkill_C* GetDefaultObj();

};

}


