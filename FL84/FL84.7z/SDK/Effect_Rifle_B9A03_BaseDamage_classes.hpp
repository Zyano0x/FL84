#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x198 - 0x198)
// BlueprintGeneratedClass Effect_Rifle_B9A03_BaseDamage.Effect_Rifle_B9A03_BaseDamage_C
class UEffect_Rifle_B9A03_BaseDamage_C : public USolarAbilityEffect
{
public:

	static class UClass* StaticClass();
	static class UEffect_Rifle_B9A03_BaseDamage_C* GetDefaultObj();

};

}


