#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x198 - 0x198)
// BlueprintGeneratedClass Effect_VH_Hover_Soroll03_TurretA1_BaseDamage.Effect_VH_Hover_Soroll03_TurretA1_BaseDamage_C
class UEffect_VH_Hover_Soroll03_TurretA1_BaseDamage_C : public USolarAbilityEffect
{
public:

	static class UClass* StaticClass();
	static class UEffect_VH_Hover_Soroll03_TurretA1_BaseDamage_C* GetDefaultObj();

};

}


