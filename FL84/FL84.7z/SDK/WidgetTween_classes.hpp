#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x388 - 0x388)
// WidgetBlueprintGeneratedClass WidgetTween.WidgetTween_C
class UWidgetTween_C : public UTweenWidget
{
public:

	static class UClass* StaticClass();
	static class UWidgetTween_C* GetDefaultObj();

};

}


