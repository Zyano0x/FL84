#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x310 - 0x308)
// BlueprintGeneratedClass Ability_Rifle_B9A05_BaseDamage_2.Ability_Rifle_B9A05_BaseDamage_2_C
class AAbility_Rifle_B9A05_BaseDamage_2_C : public ASolarAbility
{
public:
	uint8                                        Pad_1834[0x8];                                     // Fixing Size Of Struct [ Dumper-7 ]

	static class UClass* StaticClass();
	static class AAbility_Rifle_B9A05_BaseDamage_2_C* GetDefaultObj();

};

}


