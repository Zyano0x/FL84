#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x510 - 0x508)
// BlueprintGeneratedClass Projectile_VH_Hover_Soroll02_AutoGun.Projectile_VH_Hover_Soroll02_AutoGun_C
class AProjectile_VH_Hover_Soroll02_AutoGun_C : public ADefaultProjBullet_C
{
public:
	class UParticleSystemComponent*              Bullet;                                            // 0x508(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class AProjectile_VH_Hover_Soroll02_AutoGun_C* GetDefaultObj();

};

}


