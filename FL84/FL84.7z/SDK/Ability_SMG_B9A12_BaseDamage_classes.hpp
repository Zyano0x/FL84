#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x310 - 0x308)
// BlueprintGeneratedClass Ability_SMG_B9A12_BaseDamage.Ability_SMG_B9A12_BaseDamage_C
class AAbility_SMG_B9A12_BaseDamage_C : public ASolarAbility
{
public:
	uint8                                        Pad_184F[0x8];                                     // Fixing Size Of Struct [ Dumper-7 ]

	static class UClass* StaticClass();
	static class AAbility_SMG_B9A12_BaseDamage_C* GetDefaultObj();

};

}


