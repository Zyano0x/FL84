#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass BP_SettlementStageMgr.BP_SettlementStageMgr_C
class UBP_SettlementStageMgr_C : public USettlementStageManager
{
public:

	static class UClass* StaticClass();
	static class UBP_SettlementStageMgr_C* GetDefaultObj();

};

}


