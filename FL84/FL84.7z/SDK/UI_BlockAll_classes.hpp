#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x350 - 0x348)
// WidgetBlueprintGeneratedClass UI_BlockAll.UI_BlockAll_C
class UUI_BlockAll_C : public USolarUserWidget
{
public:
	class UCanvasPanel*                          Panel_Block;                                       // 0x348(0x8)(BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UUI_BlockAll_C* GetDefaultObj();

	class FString GetModuleName();
};

}


