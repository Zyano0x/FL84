#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x478 - 0x478)
// BlueprintGeneratedClass ChaGABP_Reload.ChaGABP_Reload_C
class UChaGABP_Reload_C : public UChaGA_Reload
{
public:

	static class UClass* StaticClass();
	static class UChaGABP_Reload_C* GetDefaultObj();

};

}


