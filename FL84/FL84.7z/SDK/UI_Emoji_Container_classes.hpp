#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x398 - 0x398)
// WidgetBlueprintGeneratedClass UI_Emoji_Container.UI_Emoji_Container_C
class UUI_Emoji_Container_C : public UUIEmojiContainer
{
public:

	static class UClass* StaticClass();
	static class UUI_Emoji_Container_C* GetDefaultObj();

};

}


