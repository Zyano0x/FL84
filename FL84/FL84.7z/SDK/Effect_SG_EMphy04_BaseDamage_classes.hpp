#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x198 - 0x198)
// BlueprintGeneratedClass Effect_SG_EMphy04_BaseDamage.Effect_SG_EMphy04_BaseDamage_C
class UEffect_SG_EMphy04_BaseDamage_C : public USolarAbilityEffect
{
public:

	static class UClass* StaticClass();
	static class UEffect_SG_EMphy04_BaseDamage_C* GetDefaultObj();

};

}


