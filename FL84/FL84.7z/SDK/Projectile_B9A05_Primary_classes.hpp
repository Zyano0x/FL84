#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x508 - 0x508)
// BlueprintGeneratedClass Projectile_B9A05_Primary.Projectile_B9A05_Primary_C
class AProjectile_B9A05_Primary_C : public ADefaultProjBullet_C
{
public:

	static class UClass* StaticClass();
	static class AProjectile_B9A05_Primary_C* GetDefaultObj();

};

}


